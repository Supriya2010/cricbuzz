export class Playerlist1{
    name1:string;

    constructor(name1:string){
    this.name1=name1;
    }
}
