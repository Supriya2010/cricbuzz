export class Commentry{
    balls:any;
    overs:any;
    description:string;

    constructor(balls:any,overs:any,description:string){
       this.balls=balls;
       this.overs=overs;
       this.description=description;
    }
}