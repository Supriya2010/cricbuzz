export class Playerlist1{
 name2:string;

 constructor(name2:string){
   this.name2=name2;
 }
}